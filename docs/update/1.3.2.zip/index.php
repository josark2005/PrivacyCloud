<?php
// +----------------------------------------------------------------------
// | Writed by Jokin [ Think & Do & To Be Better ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016-2018 Jokin All rights reserved.
// +----------------------------------------------------------------------
// | Author: Jokin <Jokin@twocola.com>
// +----------------------------------------------------------------------

/**
 * Privacy Cloud
 * @author Jokin
**/

/**
 * 1.3.1自动升级注意
 * 所有配置项已全部整理至入口文件同级目录下config.inc.php
**/


/* ！以下内容请勿修改 */
// Load core
include "./lib/core.class.php";
\PrivacyCloud\Core::initialize();
?>
