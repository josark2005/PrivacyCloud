<?php
// +----------------------------------------------------------------------
// | Constructed by Jokin [ Think & Do & To Be Better ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016-2018 Jokin All rights reserved.
// +----------------------------------------------------------------------
// | Author: Jokin <Jokin@twocola.com>
// +----------------------------------------------------------------------

/**
 * Privacy Cloud
 * @author Jokin
**/


/* ！以下内容请勿修改 */
// Load core
include "./lib/core.class.php";
\PrivacyCloud\Core::initialize();
?>
